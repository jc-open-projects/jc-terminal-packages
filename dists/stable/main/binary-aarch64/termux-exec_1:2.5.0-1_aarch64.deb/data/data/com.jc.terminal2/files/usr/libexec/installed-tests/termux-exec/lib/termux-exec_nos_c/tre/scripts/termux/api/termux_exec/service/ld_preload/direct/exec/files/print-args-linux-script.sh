#!/data/data/com.jc.terminal2/files/usr/bin/sh

echo "$@"
