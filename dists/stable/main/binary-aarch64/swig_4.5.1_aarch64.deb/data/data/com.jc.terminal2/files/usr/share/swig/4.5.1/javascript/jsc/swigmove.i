%include <typemaps/swigmove.swg>
