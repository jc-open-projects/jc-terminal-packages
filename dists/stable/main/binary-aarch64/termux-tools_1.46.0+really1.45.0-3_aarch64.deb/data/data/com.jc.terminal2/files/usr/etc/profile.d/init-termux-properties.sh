if [ ! -f /data/data/com.jc.terminal2/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.jc.terminal2/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.jc.terminal2/files/home/.termux
	cp /data/data/com.jc.terminal2/files/usr/share/examples/termux/termux.properties /data/data/com.jc.terminal2/files/home/.termux/
fi
