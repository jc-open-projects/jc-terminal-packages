##
## This script is sourced by /data/data/com.jc.terminal2/files/usr/bin/login before executing shell.
##
