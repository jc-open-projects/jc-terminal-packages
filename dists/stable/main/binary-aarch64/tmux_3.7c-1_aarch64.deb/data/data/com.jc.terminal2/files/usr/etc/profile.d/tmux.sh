export TMUX_TMPDIR=/data/data/com.jc.terminal2/files/usr/var/run
