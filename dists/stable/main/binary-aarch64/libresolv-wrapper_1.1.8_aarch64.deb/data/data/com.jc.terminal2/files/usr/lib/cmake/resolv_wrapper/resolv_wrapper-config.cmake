set(RESOLV_WRAPPER_LIBRARY /data/data/com.jc.terminal2/files/usr/lib/libresolv_wrapper.so)
